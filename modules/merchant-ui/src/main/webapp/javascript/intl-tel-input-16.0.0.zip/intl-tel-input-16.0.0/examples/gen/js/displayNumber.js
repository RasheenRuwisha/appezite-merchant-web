var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1560794689211" // just for formatting/placeholders etc
});
